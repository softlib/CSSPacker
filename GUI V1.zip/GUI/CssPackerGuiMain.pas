unit CssPackerGuiMain;

interface

uses
  Winapi.Windows,
  Winapi.Messages,
  System.SysUtils,
  System.Classes,
  System.StrUtils,
  System.IOUtils,
  Vcl.Graphics,
  Vcl.Controls,
  Vcl.Forms,
  Vcl.Dialogs,
  Vcl.StdCtrls,
  Vcl.ExtCtrls,
  Vcl.ComCtrls,
  Vcl.Clipbrd,
  CssPacker.Core;

type
  TfrmMain = class(TForm)
    pnlTop: TPanel;
    btnOpen: TButton;
    btnSave: TButton;
    btnProcess: TButton;
    btnSwap: TButton;
    btnCopy: TButton;
    btnClear: TButton;
    pnlOptions: TPanel;
    lblMode: TLabel;
    cboMode: TComboBox;
    lblIndent: TLabel;
    cboIndent: TComboBox;
    lblEOL: TLabel;
    cboEOL: TComboBox;
    chkKeepComments: TCheckBox;
    chkLicense: TCheckBox;
    chkHex: TCheckBox;
    chkZero: TCheckBox;
    chkLeadingZero: TCheckBox;
    chkFinalSemi: TCheckBox;
    chkCharset: TCheckBox;
    chkBlankLines: TCheckBox;
    chkTabs: TCheckBox;
    pnlInput: TPanel;
    lblInput: TLabel;
    memInput: TMemo;
    splitter: TSplitter;
    pnlOutput: TPanel;
    lblOutput: TLabel;
    memOutput: TMemo;
    statusBar: TStatusBar;
    dlgOpen: TOpenDialog;
    dlgSave: TSaveDialog;
    procedure ButtonOpenClick(Sender: TObject);
    procedure ButtonSaveClick(Sender: TObject);
    procedure ButtonProcessClick(Sender: TObject);
    procedure ButtonCopyClick(Sender: TObject);
    procedure ButtonSwapClick(Sender: TObject);
    procedure ButtonClearClick(Sender: TObject);
    procedure ModeChanged(Sender: TObject);
  private
    CurrentFile: string;
    function GetOptions: TCssOptions;
    procedure UpdateStatus(const S: string);
  public
    constructor Create(AOwner: TComponent); override;
  end;

implementation

{$R *.dfm}

{ The entire visual design lives in CssPackerGuiMain.dfm so the form can be
  opened and edited visually in the Delphi IDE. Only dynamic, version-dependent
  values are applied here at runtime. }

constructor TfrmMain.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  Caption := 'CssPacker - Universal CSS Pack / Unpack Tool  [' + TCssPacker.Version + ']';
  UpdateStatus('Ready - load a CSS file or paste CSS into the input pane.');
end;

procedure TfrmMain.UpdateStatus(const S: string);
begin
  statusBar.Panels[0].Text := S;
end;

function TfrmMain.GetOptions: TCssOptions;
begin
  Result := TCssOptions.Default;
  case cboMode.ItemIndex of
    1: Result.Operation := coPackSafe;
    2: Result.Operation := coPackAggressive;
    3: Result.Operation := coUnpackPretty;
  else
    Result.Operation := coAuto;
  end;

  if cboIndent.ItemIndex = cboIndent.Items.Count - 1 then
  begin
    Result.UseTabs := True;
    Result.IndentSize := 1;
  end
  else
    Result.IndentSize := StrToIntDef(cboIndent.Text, 2);
  Result.UseTabs := Result.UseTabs or chkTabs.Checked;

  case cboEOL.ItemIndex of
    1: Result.LineEnding := #10;
    2: Result.LineEnding := #13#10;
    3: Result.LineEnding := #13;
  else
    Result.LineEnding := sLineBreak;
  end;

  Result.RemoveComments := not chkKeepComments.Checked;
  Result.KeepLicenseComments := chkLicense.Checked;
  Result.ShortenHexColors := chkHex.Checked;
  Result.RemoveZeroUnits := chkZero.Checked;
  Result.RemoveLeadingZero := chkLeadingZero.Checked;
  Result.RemoveFinalSemicolon := chkFinalSemi.Checked;
  Result.RemoveCharset := chkCharset.Checked;
  Result.BlankLineBetweenRules := chkBlankLines.Checked;
end;

procedure TfrmMain.ModeChanged(Sender: TObject);
begin
  case cboMode.ItemIndex of
    2:  { pack-fast: enable optimisations }
      begin
        chkHex.Checked := True;
        chkZero.Checked := True;
        chkLeadingZero.Checked := True;
      end;
  end;
end;

procedure TfrmMain.ButtonOpenClick(Sender: TObject);
var
  Enc: TEncoding;
  HasBOM: Boolean;
  Text: string;
begin
  if not dlgOpen.Execute then Exit;
  try
    Text := TCssPacker.ReadTextFile(dlgOpen.FileName, Enc, HasBOM);
    memInput.Text := Text;
    CurrentFile := dlgOpen.FileName;
    UpdateStatus('Loaded: ' + ExtractFileName(CurrentFile) + '  (' +
      IntToStr(Length(Text)) + ' chars)');
    Caption := 'CssPacker - ' + ExtractFileName(CurrentFile);
  except
    on E: Exception do ShowMessage('Open failed: ' + E.Message);
  end;
end;

procedure TfrmMain.ButtonSaveClick(Sender: TObject);
var
  Enc: TEncoding;
  HasBOM: Boolean;
  Dummy: string;
begin
  if memOutput.Text = '' then
  begin
    ShowMessage('Nothing to save. Run Process first.');
    Exit;
  end;
  if not dlgSave.Execute then Exit;
  try
    if (CurrentFile <> '') and FileExists(CurrentFile) then
      Dummy := TCssPacker.ReadTextFile(CurrentFile, Enc, HasBOM)
    else
    begin
      Enc := TEncoding.UTF8;
      HasBOM := False;
    end;
    TCssPacker.WriteTextFile(dlgSave.FileName, memOutput.Text, Enc, HasBOM);
    UpdateStatus('Saved: ' + ExtractFileName(dlgSave.FileName));
  except
    on E: Exception do ShowMessage('Save failed: ' + E.Message);
  end;
end;

procedure TfrmMain.ButtonProcessClick(Sender: TObject);
var
  Opts: TCssOptions;
  Stats: TCssStats;
  Output: string;
  EffectiveOp: TCssOperation;
begin
  if memInput.Text = '' then
  begin
    UpdateStatus('Input is empty.');
    Exit;
  end;
  try
    Opts := GetOptions;
    Output := TCssPacker.Format(memInput.Text, Opts, Stats);
    memOutput.Text := Output;
    EffectiveOp := Opts.Operation;
    if EffectiveOp = coAuto then
      EffectiveOp := TCssPacker.DetectOperation(memInput.Text);
    UpdateStatus(Format('Done: %s | %d -> %d bytes (%.1f%% saved) | %d rules | %d ms',
      [TCssPacker.OperationName(EffectiveOp),
       Stats.InputBytes, Stats.OutputBytes, Stats.CompressionPercent,
       Stats.RuleCount, Stats.ElapsedMs]));
    statusBar.Panels[1].Text := 'Lines: ' + IntToStr(Stats.InputLines) + ' -> ' + IntToStr(Stats.OutputLines);
    statusBar.Panels[2].Text := 'Declarations: ' + IntToStr(Stats.DeclarationCount);
    statusBar.Panels[3].Text := 'Comments: ' + IntToStr(Stats.CommentCount);
  except
    on E: Exception do ShowMessage('Processing failed: ' + E.Message);
  end;
end;

procedure TfrmMain.ButtonCopyClick(Sender: TObject);
begin
  if memOutput.Text = '' then Exit;
  Clipboard.AsText := memOutput.Text;
  UpdateStatus('Output copied to clipboard.');
end;

procedure TfrmMain.ButtonSwapClick(Sender: TObject);
var
  T: string;
begin
  T := memInput.Text;
  memInput.Text := memOutput.Text;
  memOutput.Text := T;
  UpdateStatus('Input / output swapped.');
end;

procedure TfrmMain.ButtonClearClick(Sender: TObject);
begin
  memInput.Clear;
  memOutput.Clear;
  CurrentFile := '';
  Caption := 'CssPacker - Universal CSS Pack / Unpack Tool';
  UpdateStatus('Cleared.');
end;

end.
